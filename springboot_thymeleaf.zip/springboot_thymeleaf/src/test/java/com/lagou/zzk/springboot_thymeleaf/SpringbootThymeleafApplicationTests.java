package com.lagou.zzk.springboot_thymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;

import com.lagou.zzk.springboot_thymeleaf.pojo.Article;
import com.lagou.zzk.springboot_thymeleaf.service.ArticleService;

@SpringBootTest
class SpringbootThymeleafApplicationTests {
    
    @Autowired
    private ArticleService articleService;

    @Test
    void contextLoads() {

        Page<Article> page = articleService.findArticleByPage(1, 3);
        
        System.out.println(page);
    }

}
