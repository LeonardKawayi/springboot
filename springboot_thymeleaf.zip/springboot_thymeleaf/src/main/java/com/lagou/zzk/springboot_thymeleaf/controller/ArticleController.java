package com.lagou.zzk.springboot_thymeleaf.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lagou.zzk.springboot_thymeleaf.pojo.Article;
import com.lagou.zzk.springboot_thymeleaf.service.ArticleService;

/**
 * @author zhangzhenkun <zhangzhenkun@kuaishou.com>
 * Created on 2020-02-17
 */
@Controller
@RequestMapping("/article")
public class ArticleController {

    @Autowired
    private ArticleService articleService;

    @RequestMapping("/page/list")
    public String  queryPage(Model model, Integer page, Integer size) {
        Page<Article> articles = articleService.findArticleByPage(page, size);
        model.addAttribute("articles", articles);

        return "client/index";
    }
}
