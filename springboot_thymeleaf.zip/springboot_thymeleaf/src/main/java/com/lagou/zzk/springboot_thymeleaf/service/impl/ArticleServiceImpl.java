package com.lagou.zzk.springboot_thymeleaf.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.lagou.zzk.springboot_thymeleaf.pojo.Article;
import com.lagou.zzk.springboot_thymeleaf.repository.ArticleRepository;
import com.lagou.zzk.springboot_thymeleaf.service.ArticleService;

/**
 * @author zhangzhenkun <zhangzhenkun@kuaishou.com>
 * Created on 2020-02-17
 */
@Service
public class ArticleServiceImpl implements ArticleService {

    @Autowired
    private ArticleRepository articleRepository;

    @Override
    public Page<Article> findArticleByPage(Integer page, Integer size) {

        Sort sort = Sort.by(Direction.DESC, "id");

        Pageable pageable = PageRequest.of(page,size,sort);

        return articleRepository.findAll(pageable);
    }
}
