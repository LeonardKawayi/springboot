package com.lagou.zzk.springboot_thymeleaf.service;

import org.springframework.data.domain.Page;

import com.lagou.zzk.springboot_thymeleaf.pojo.Article;

/**
 * @author zhangzhenkun <zhangzhenkun@kuaishou.com>
 * Created on 2020-02-17
 */
public interface ArticleService {

    Page<Article> findArticleByPage(Integer page,Integer size);

}
