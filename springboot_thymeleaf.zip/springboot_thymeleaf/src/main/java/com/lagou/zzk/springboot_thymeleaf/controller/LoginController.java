package com.lagou.zzk.springboot_thymeleaf.controller;

import java.util.Calendar;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author zhangzhenkun <zhangzhenkun@kuaishou.com>
 * Created on 2020-02-16
 */
@Controller
public class LoginController {

    @RequestMapping("/login")
    public String login (Model model) {

        model.addAttribute("currentYear", Calendar.getInstance().get(Calendar.YEAR));
        return "login";
    }
}
